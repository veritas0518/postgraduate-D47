import java.util.Scanner;

public class TestFraction {
    public static void main(String[] args) {

        Fraction f1=null,f2=null;
        f1 = new Fraction();
        f2 = new Fraction();



        Scanner sc = new Scanner(System.in);



        System.out.println("Please enter fraction f1:");

        // 在此实现：输入两个int类型的变量n1和d1，构造出分数对象f1
        f1.nume = sc.nextInt();
        f1.deno = sc.nextInt();
        f1 = new Fraction(f1.nume, f1.deno);

        System.out.println("Please enter fraction f2:");

        // 在此实现：输入两个int类型的变量n2和d2，构造出分数对象f2
        f2.nume = sc.nextInt();
        f2.deno = sc.nextInt();
        if(f2.nume == 0){
            System.out.println("Cannot be divided by zero!");
            System.exit(0);
        }

        f2 = new Fraction(f2.nume, f2.deno);


        sc.close();



        // 在此实现：分数对象f1和f2的加减乘除操作，
        // 将运算结果（4个分数对象）依次保存到addRet,subRet,mulRet,divRet中

        Fraction addRet=null,subRet=null,mulRet=null,divRet=null;
        addRet=f1.add(f2);
        subRet=f1.sub(f2);
        mulRet=f1.mul(f2);
        divRet=f1.div(f2);




        // 输出分数的运算结果

        System.out.println(f1 + " + " + f2 + " = " + addRet.toString());

        System.out.println(f1 + " - " + f2 + " = " + subRet.toString());

        System.out.println(f1 + " * " + f2 + " = " + mulRet.toString());

        System.out.println(f1 + " / " + f2 + " = " + divRet.toString());



        System.out.println(f1 + " equals " + f2 +" ? "+f1.equals(f2));

    }
}

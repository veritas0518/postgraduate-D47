public class Fraction {
    int nume; // numerator

    int deno; // denominator



    Fraction() {

        // deno = 1;

        this(0, 1);

    }



    Fraction(int nume, int denu) {

        this.nume = nume;

        this.deno = denu;

        reduce();

    }



    // 请完善add方法的方法体，实现当前对象与传入对象fo的相加，将结果对象返回。

    Fraction add(Fraction fo) {
        int fq = this.nume * fo.deno + this.deno * fo.nume;
        int fw = this.deno * fo.deno;
        Fraction e = new Fraction(fq,fw);
        return e;

    }



    // 请完善sub方法的方法体，实现当前对象与传入对象fo的相减，将结果对象返回。

    Fraction sub(Fraction fo) {
        int fq = this.nume * fo.deno - this.deno * fo.nume;
        int fw = this.deno * fo.deno;
        Fraction e = new Fraction(fq,fw);
        return e;

    }



    // 请完善mul方法的方法体，实现当前对象与传入对象fo的相乘，将结果对象返回。

    Fraction mul(Fraction fo) {
        int fq = this.nume * fo.nume ;
        int fw = this.deno * fo.deno;
        Fraction e = new Fraction(fq,fw);
        return e;


    }



    // 请完善mul方法的方法体，实现当前对象与传入对象fo的相乘，将结果对象返回。

    Fraction div(Fraction fo) {
        int fq = this.nume * fo.deno;
        int fw = this.deno * fo.nume;
        Fraction e = new Fraction(fq,fw);
        return e;

    }



    // 求最大公约数

    int getMaxComFactor(int m, int n) {

        if (nume == 0)

            return 1;



        if (m < n) {

            // int tmp = m;

            // m = n;

            // n = tmp;

            // m=3, n=5

            m = m + n;

            n = m - n;

            m = m - n;

        }



        int r = m % n;

        while (r != 0) { // C: while(!r)

            m = n;

            n = r;

            r = m % n;

        }



        return n;

    }



    // 约分方法

    void reduce() {

        if (deno == 0) {

            System.out.println("The denominator cannot be zero!");

            System.exit(-1);

        }



        int sign = 1;

        if (nume * deno < 0) {

            sign = -1;

        }



        int absNume = Math.abs(nume);

        int absDenu = Math.abs(deno);



        int maxFac = getMaxComFactor(absNume, absDenu);

        nume = absNume / maxFac * sign;

        deno = absDenu / maxFac;

    }



    @Override

    public String toString() {

        if (nume == 0)

            return "0";

        else if (nume == deno)

            return "1";

        else

            return nume + "/" + deno;

    }



    @Override

    public boolean equals(Object obj) {

        if (this == obj)

            return true;

        else if (obj.getClass() == Fraction.class) {

            Fraction ft = (Fraction) obj;

            if (ft.nume == this.nume && ft.deno == this.deno)

                return true;

            else

                return false;

        } else {

            return false;

        }

    }
}
